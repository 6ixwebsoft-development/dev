 <?php $__env->startSection('breadcrumb'); ?>
<!-- Breadcrumb-->
<ol class="breadcrumb">
	<li class="breadcrumb-item">Home</li>
	<li class="breadcrumb-item"> <a href="#">Admin</a>
	</li>
	<li class="breadcrumb-item active">Dashboard</li>
	<!-- Breadcrumb Menu-->
	<li class="breadcrumb-menu d-md-down-none">
		<div class="btn-group" role="group" aria-label="Button group">
			<a class="btn" href="#"> <i class="icon-speech"></i>
			</a>
			<a class="btn" href="./"> <i class="icon-graph"></i>  Dashboard</a>
			<a class="btn" href="#"> <i class="icon-settings"></i>  Settings</a>
		</div>
	</li>
</ol>

<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-sm-5">
						<h4 class="card-title mb-0">
                   			City  Management <small class="text-muted">city</small>
               			</h4>
					</div>
					<!--col-->
					<div class="col-sm-7">
						<div class="btn-toolbar float-right" role="toolbar" aria-label="Create"> <a href="<?php echo url('/admin/location/city/create');; ?>" class="btn btn-success ml-1" data-toggle="tooltip" title="Create"><i class="fas fa-plus-circle"></i></a>
						</div>
					</div>
					<!--col-->
				</div>
				<!--row-->
				<hr>
				<table class="table table-bordered location-city-table">
					<thead>
						<tr>
							<th>No</th>
							<th>Country Name</th>
							<th>Region Name</th>
							<th>City Name</th>
							<th>Status</th>
							<th width="100px">Action</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\globalgrant\resources\views/admin/location/city/index.blade.php ENDPATH**/ ?>