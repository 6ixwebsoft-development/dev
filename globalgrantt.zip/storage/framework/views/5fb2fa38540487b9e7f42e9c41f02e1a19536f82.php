<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-title">
                <b>GENERAL</b>
            </li>
            <li class="nav-item">
                <a class="nav-link " href="<?php echo url('/admin');; ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                  Dashboard
                </a>
            </li>

            <li class="nav-title">
                <b>SYSTEM</b>
            </li>
                <li class="divider"></li>
                <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                        <i class="nav-icon fas fa-language"></i>Languages
                    </a>

                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link " href="<?php echo url('/admin/language');; ?>">
                               Manage Language 
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo url('/admin/translation');; ?>">
                              Manage Translation
                            </a>
                        </li>
                    </ul>
                </li>
               
                 
           
        </ul>
    </nav>

    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div><!--sidebar-->

<?php /**PATH C:\wamp64\www\globalgrant\resources\views\admin\includes\sidebar.blade.php ENDPATH**/ ?>