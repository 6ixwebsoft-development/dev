 <?php $__env->startSection('breadcrumb'); ?>
<!-- Breadcrumb-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item"> <a href="#">Admin</a>
    </li>
    <li class="breadcrumb-item active">Dashboard</li>
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu d-md-down-none">
        <div class="btn-group" role="group" aria-label="Button group">
            <a class="btn" href="#"> <i class="icon-speech"></i>
            </a>
            <a class="btn" href="./"> <i class="icon-graph"></i>  Dashboard</a>
            <a class="btn" href="#"> <i class="icon-settings"></i>  Settings</a>
        </div>
    </li>
</ol>
<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-5">
                        <h4 class="card-title mb-0">
                        Create Module <small class="text-muted">Module</small>
                        </h4>
                    </div>
                    <!--col-->
                    <div class="col-sm-7">
                        
                    </div>
                    <!--col-->
                </div>
                <!--row-->
                <hr>
                <?php echo Form::open(array('route' => array('admin.foundation.update', $foundation->id))); ?>

                    
                    <div class="row">
                        <div class="col-12">
                            <div class="nav nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="false">Basic Info</a>
                                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Criteria</a>
                         
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="tab-content " class="bottom_style" id="v-pills-tabContent">
                                <div class="tab-pane fade active show" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                                    <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('name', __( 'Name' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                               <?php echo Form::text('name', !empty($foundation->name) ? $foundation->name : '', ['class' => 'form-control', '', 'placeholder' => __( 'Name' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('sort-name', __( 'Sort Name' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                    <?php echo Form::text('sort_name', !empty($foundation->sort) ? $foundation->sort : '', ['class' => 'form-control', '', 'placeholder' => __( 'Sort Name' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('source', __( 'Source' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                    <?php echo Form::text('source', !empty($foundation->source) ? $foundation->source : '', ['class' => 'form-control', '', 'placeholder' => __( 'Source' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('type', __( 'Type' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('type', !empty($foundation->type) ? $foundation->type : '', ['class' => 'form-control', '', 'placeholder' => __( 'Type' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('availability', __( 'Availability' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                               
                                                <?php echo Form::select('availability', array('1' => 'Yes', '2' => 'No'), '1', ['class' => 'form-control']);; ?>

                                                    
                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div>

                                    <div class="col-md-6"> 
                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('status', __( 'Status' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::select('status', array('1' => 'active', '2' => 'inactive'), !empty($foundation->status) ? $foundation->status : '', ['class' => 'form-control']);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('language', __( 'Language' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::select('language_id', array('1' => 'English', '2' => 'Sweedish'), '1', ['class' => 'form-control']);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('admin', __( 'Admin' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                    <?php echo Form::text('admin', !empty($foundation->administrator) ? $foundation->administrator : '', ['class' => 'form-control', '', 'placeholder' => __( 'Admin' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('asset', __( 'Assets' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('asset', !empty($foundation->asset) ? $foundation->asset : '', ['class' => 'form-control', '', 'placeholder' => __( 'Assets' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('org-no', __( 'Org. No' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('org_no', !empty($foundation->org_no) ? $foundation->org_no : '', ['class' => 'form-control', '', 'placeholder' => __( 'Org No' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('remarks', __( 'Remarks' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::textarea('remarks', !empty($foundation->remarks) ? $foundation->remarks : '', ['class' => 'form-control', '', 'placeholder' => __( 'remarks' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div> 
                                    <div class="col-md-12">
                                        <h4>Public Details</h4>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('email', __( 'Email' ) . ':*'); ?>

                                            </div>
                                            <!-- !empty($location_printer_type) ? $location_printer_type : 'browser' -->
                                            <div class="col-md-9">
                                                <?php echo Form::text('email', !empty($contact->email) ? $contact->email : '', ['class' => 'form-control', '', 'placeholder' => __( 'Email' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('mobile', __( 'Mobile' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">

                                                <?php echo Form::text('mobile', !empty($contact->mobile_no) ? $contact->mobile_no : '', ['class' => 'form-control', '', 'placeholder' => __( 'Mobile' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('address-1', __( 'Address 1' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('address_1', !empty($contact->address1) ? $contact->address1 : '', ['class' => 'form-control', '', 'placeholder' => __( 'Address-1' ) ]);; ?>

                                                
                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('address-2', __( 'Address Line 2' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('address_2', !empty($contact->address2) ? $contact->address2 : '', ['class' => 'form-control', '', 'placeholder' => __( 'Address-2' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('address-3', __( 'Address line 3' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('address_3', !empty($contact->address3) ? $contact->address3 : '', ['class' => 'form-control', '', 'placeholder' => __( 'Address-3' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('phone', __( 'Phone' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('phone', !empty($contact->phone_no) ? $contact->phone_no : '', ['class' => 'form-control', '', 'placeholder' => __( 'Phone' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                        
                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('zip-code', __( 'Zip Code' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('zipcode', !empty($contact->zip) ? $contact->zip : '', ['class' => 'form-control', '', 'placeholder' => __( 'Zip Code' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('website', __( 'Website' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('website', !empty($contact->website) ? $contact->website : '', ['class' => 'form-control', '', 'placeholder' => __( 'Website' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                    </div>

                                    <div class="col-md-12">
                                        <h4>Private Details</h4>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('c-email', __( 'Email' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('c_email', !empty($contact->c_email) ? $contact->c_email : '', ['class' => 'form-control', '', 'placeholder' => __( 'Email' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('c-phone', __( 'Phone' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('c_phone', !empty($contact->c_phone_no) ? $contact->c_phone_no : '', ['class' => 'form-control', '', 'placeholder' => __( 'Phone' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('c-address', __( 'Address' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('c_address', !empty($contact->c_address) ? $contact->c_address : '', ['class' => 'form-control', '', 'placeholder' => __( 'Address' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                        
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('c-name', __( 'Name' ) . ':*'); ?>

                                            </div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('c_name', !empty($contact->c_name) ? $contact->c_name : '', ['class' => 'form-control', '', 'placeholder' => __( 'Name' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
                                                <?php echo Form::label('c-mobile', __( 'Mobile' ) . ':*'); ?>

                                            </div>
                                            <div class="col-md-9">
                                                <?php echo Form::text('c_mobile', !empty($contact->c_mobile_no) ? $contact->c_mobile_no : '', ['class' => 'form-control', '', 'placeholder' => __( 'Mobile' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div>

                                </div>
                                </div>
                                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                                    <div class="row">
                                    <div class="col-md-2">
                                        <div class="f_purpose">
                                            <h4>Purpose</h4>
                                            <?php echo Form::select('purpose_ids[]', $purpose, $selectedPurpose, ['class' => 'form-control', 'multiple' => 'multiple']);; ?>

                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="f_gender">
                                            <h4>Genders</h4>
                                            <?php echo Form::select('gender_ids[]', $gender, $selectedGender, ['class' => 'form-control', 'multiple' => 'multiple']);; ?>

                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="f_age">
                                            <h4>Age</h4>
                                            <div class="form-group row">
                                                <div class="col-lg-3">
                                                    <?php echo Form::label('age-from', __( 'Age From' ) . ':*'); ?>

                                                </div>

                                                <div class="col-md-9">
                                                    <?php echo Form::text('age_from', !empty($age->from) ? $age->from : '', ['class' => 'form-control', '', 'placeholder' => __( 'Age From' ) ]);; ?>

                                                </div><!--col-->
                                            </div><!--form-group-->
                                            <div class="form-group row">
                                                <div class="col-lg-3">
                                                    <?php echo Form::label('age-to', __( 'Age To' ) . ':*'); ?>

                                                </div>

                                                <div class="col-md-9">
                                                    <?php echo Form::text('age_to', !empty($age->to) ? $age->to : '', ['class' => 'form-control', '', 'placeholder' => __( 'Age To' ) ]);; ?>

                                                </div><!--col-->
                                            </div><!--form-group-->
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="f_gender">
                                            <h4>Subject</h4>
                                            <?php echo Form::select('subject_ids[]', $subject, $selectedSubject, ['class' => 'form-control', 'multiple' => 'multiple']);; ?>

                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="f_gender">
                                            <h4>Location</h4>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <?php echo Form::label('country-block', __( 'Country Block' ) . ':*'); ?>

                                                    <?php echo Form::select('country_block', $blocks_arr, !empty($location->nation_id) ? $location->nation_id : '', ['class' => 'form-control']);; ?>

                                                </div><!--col-->
                                                <div class="col-md-2">
                                                    <?php echo Form::label('country', __( 'Country' ) . ':*'); ?>

                                                    <?php echo Form::select('country', $country_arr, !empty($location->country_id) ? $location->country_id : '', ['class' => 'form-control']);; ?>

                                                </div><!--col-->
                                                <div class="col-md-2">
                                                    <?php echo Form::label('region', __( 'Region' ) . ':*'); ?>

                                                    <?php echo Form::select('region', $region_arr, !empty($location->region_id) ? $location->region_id : '', ['class' => 'form-control']);; ?>

                                                </div><!--col-->
                                                <div class="col-md-2">
                                                    <?php echo Form::label('city', __( 'City' ) . ':*'); ?>

                                                    <?php echo Form::select('city', $city_arr, !empty($location->city_id) ? $location->city_id : '', ['class' => 'form-control']);; ?>

                                                </div><!--col-->
                                                <div class="col-md-2">
                                                    <?php echo Form::label('parish', __( 'Parish' ) . ':*'); ?>

                                                    
                                                    <?php echo Form::text('parish', !empty($location->parish) ? $location->parish : '', ['class' => 'form-control', '', 'placeholder' => __( 'Parish' ) ]);; ?>

                                                </div><!--col-->
                                                <div class="col-md-2">
                                                </div><!--col-->
                                            </div><!--row-->

                                        </div>
                                    </div>

                                    <!-- application dates -->
                                    <div class="col-md-12">
                                        <div class="app_dates">
                                            <h4>Application Dates</h4>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <?php echo Form::label('app_start_day', __( 'Application Start' ) . ':*'); ?>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <?php echo Form::select('apply_start_month',$months, !empty($dates->start_month) ? $dates->start_month : '', ['class' => 'form-control']);; ?>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <?php echo Form::text('apply_start_day', !empty($dates->start_day) ? $dates->start_day : '', ['class' => 'form-control', '' ]);; ?>

                                                        </div>

                                                    </div> 
                                                    
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <?php echo Form::label('app_end_day', __( 'Application End' ) . ':*'); ?>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <?php echo Form::select('apply_end_month',$months, !empty($dates->end_month) ? $dates->end_month : '', ['class' => 'form-control']);; ?>

                                                        </div>
                                                        <div class="col-md-3">
                                                            <?php echo Form::text('apply_end_day', !empty($dates->end_day) ? $dates->end_day : '', ['class' => 'form-control', '' ]);; ?>

                                                        </div>

                                                    </div> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="purpose-details">
                                            <h4>Purpose</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('purpose_detail', !empty($advertise->purpose) ? $advertise->purpose : '', ['class' => 'form-control', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="purpose-details">
                                            <h4>Who Can Apply</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('who_can_apply', !empty($advertise->who_can_apply) ? $advertise->who_can_apply : '', ['class' => 'form-control', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="purpose-details">
                                            <h4>Application Details</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('application_details', !empty($advertise->details) ? $advertise->details : '', ['class' => 'form-control', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="purpose-details">
                                            <h4>Misc</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('misc', !empty($advertise->misc) ? $advertise->misc : '', ['class' => 'form-control', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer clearfix">
                        <div class="row">
                            <div class="col">
                                <a class="btn btn-danger btn-sm" href="<?php echo url('/admin/foundation');; ?>">Cancel</a>
                            </div>
                            <div class="col text-right">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </div>

                <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\globalgrant\resources\views/admin/foundation/edit.blade.php ENDPATH**/ ?>