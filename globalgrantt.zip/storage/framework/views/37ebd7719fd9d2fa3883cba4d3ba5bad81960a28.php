 </div>
    <footer class="app-footer">
      <div>
        <a href="#">CoreUI</a>
        <span>&copy; 2018 creativeLabs.</span>
      </div>
      <div class="ml-auto">
        <span>Powered by</span>
        <a href="#">CoreUI</a>
      </div>
    </footer>
    <!-- CoreUI and necessary plugins-->
    
    <!-- <script src="<?php echo e(asset('js/jquery.min.js')); ?>" defer></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('js/admin-view.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/pace.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/perfect-scrollbar.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/coreui.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/Chart.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/custom-tooltips.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
  </body>
</html>
<?php /**PATH C:\wamp64\www\globalgrant\resources\views\admin\includes\footer.blade.php ENDPATH**/ ?>