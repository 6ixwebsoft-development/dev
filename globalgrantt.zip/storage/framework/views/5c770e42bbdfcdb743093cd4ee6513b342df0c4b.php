  <div class="bottom-header">
    <div class="container">
      <div class="main-navigation">
        <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
        <ul class="menu">
          <li class="menu-item"><a href="about">About us</a></li>
          <li class="menu-item"><a href="insurance">Insurance plans</a></li>
          <li class="menu-item"><a href="resource">Resources</a></li>
          <li class="menu-item"><a href="contact-us">Contact</a></li>
        </ul> <!-- .menu -->
      </div> <!-- .main-navigation -->
      
      <div class="social-links">
        <a href="#"><i class="fa fa-facebook"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-google-plus"></i></a>
        <a href="#"><i class="fa fa-pinterest"></i></a>
      </div>
      
      <div class="mobile-navigation"></div>
    </div>
  </div>

</header> <!-- .site-header --><?php /**PATH C:\wamp64\www\globalgrant\resources\views\layouts\partials\nav.blade.php ENDPATH**/ ?>