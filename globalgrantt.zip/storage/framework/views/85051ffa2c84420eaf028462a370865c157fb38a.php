<?php $__env->startSection('breadcrumb'); ?>
  <!-- Breadcrumb-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item">
      <a href="#">Admin</a>
    </li>
    <li class="breadcrumb-item active">Dashboard</li>
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu d-md-down-none">
      <div class="btn-group" role="group" aria-label="Button group">
        <a class="btn" href="#">
        <i class="icon-speech"></i>
        </a>
        <a class="btn" href="./">
        <i class="icon-graph"></i>  Dashboard</a>
        <a class="btn" href="#">
        <i class="icon-settings"></i>  Settings</a>
      </div>
    </li>
  </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  
  <div class="row">
    
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
        	<div class="row">
	            <div class="col-sm-5">
	                <h4 class="card-title mb-0">
	                    Translation Management <small class="text-muted">Translation group Update</small>
	               
	                </h4>
	            </div><!--col-->

	           
          </div><!--row-->
          <hr>
        <?php echo Form::open(array('route' => array('admin.translation.update', $translation->id))); ?>

          <?php echo e(method_field('PATCH')); ?>

          <div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label('group', __( 'Group' ) . ':*'); ?>

            </div>
            <div class="col-lg-10">
              <?php echo Form::text('group', $translation->group, ['class' => 'form-control', '', 'placeholder' => __( 'Group' ) ]);; ?>

            </div>
          </div>
          <div class="card-footer clearfix">
              <div class="row">
                  <div class="col">
                      <a class="btn btn-danger btn-sm" href="<?php echo url('/admin/translaiton');; ?>">Cancel</a>
                  </div>
                  <div class="col text-right">
                      <button type="submit" class="btn btn-primary">Save</button>
                  </div>
              </div>
          </div>

        <?php echo Form::close(); ?>

        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\globalgrant\resources\views/admin/translation/edit.blade.php ENDPATH**/ ?>