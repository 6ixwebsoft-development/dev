<?php $__env->startSection('breadcrumb'); ?>
  <!-- Breadcrumb-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item">
      <a href="#">Admin</a>
    </li>
    <li class="breadcrumb-item active">Dashboard</li>
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu d-md-down-none">
      <div class="btn-group" role="group" aria-label="Button group">
        <a class="btn" href="#">
        <i class="icon-speech"></i>
        </a>
        <a class="btn" href="./">
        <i class="icon-graph"></i>  Dashboard</a>
        <a class="btn" href="#">
        <i class="icon-settings"></i>  Settings</a>
      </div>
    </li>
  </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  
  <div class="row">
    
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
        	<div class="row">
	            <div class="col-sm-5">
	                <h4 class="card-title mb-0">
	                    Label Management <small class="text-muted">Label Add</small>
	               
	                </h4>
	            </div><!--col-->

	           
          </div><!--row-->
          <hr>
          <?php
            $id = $_GET['id'];
          ?>
         <?php echo Form::open(array('url' => 'admin/label/store')); ?>

          
          <div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label('keyword', __( 'Keyword' ) . ':*'); ?>

            </div>
            <div class="col-lg-10">
              <?php echo Form::text('keyword', null, ['class' => 'form-control', '', 'placeholder' => __( 'Keyword' ) ]);; ?>

            </div>
          </div>
          <input type="hidden" name="group_id" value="<?php echo e($id); ?>">
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
          <div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label($language_data->language, __( $language_data->language )); ?>

            </div>
            <div class="col-lg-10">
              <?php echo Form::text('locale[]', null, ['class' => 'form-control', '', 'placeholder' => __( 'value' ) ]);; ?>

            </div>
            <input type="hidden" name="id[]" value="<?php echo e($language_data->id); ?>">
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="card-footer clearfix">
            <div class="row">
                <div class="col">
                  
                    <a class="btn btn-danger btn-sm" href="<?php echo url('/admin/'.$id.'/label/');; ?>">Cancel</a>
                </div>
                <div class="col text-right">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
          </div>

        <?php echo Form::close(); ?>

        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\globalgrant\resources\views\admin\label\create.blade.php ENDPATH**/ ?>