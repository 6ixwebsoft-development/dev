<?php $__env->startSection('breadcrumb'); ?>
  <!-- Breadcrumb-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item">
      <a href="#">Admin</a>
    </li>
    <li class="breadcrumb-item active">Dashboard</li>
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu d-md-down-none">
      <div class="btn-group" role="group" aria-label="Button group">
        <a class="btn" href="#">
        <i class="icon-speech"></i>
        </a>
        <a class="btn" href="./">
        <i class="icon-graph"></i>  Dashboard</a>
        <a class="btn" href="#">
        <i class="icon-settings"></i>  Settings</a>
      </div>
    </li>
  </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  
  <div class="row">
    
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
        	<div class="row">
	            <div class="col-sm-5">
	                <h4 class="card-title mb-0">
	                    Language Management <small class="text-muted">Language Add</small>
	               
	                </h4>
	            </div><!--col-->

	           
          </div><!--row-->
          <hr>
        <?php echo Form::open(array('route' => array('admin.language.update', $language->id))); ?>

          <?php echo e(method_field('PATCH')); ?>

          <div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label('language', __( 'Language' ) . ':*'); ?>

            </div>
            <div class="col-lg-10">
              <?php echo Form::text('language', $language->language, ['class' => 'form-control', '', 'placeholder' => __( 'Language' ) ]);; ?>

            </div>
          </div>
          <div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label('locale', __( 'Locale' ) . ':*'); ?>

            </div>
            <div class="col-lg-10">
              <?php echo Form::text('locale', $language->locale, ['class' => 'form-control', '', 'placeholder' => __( 'Language' ) ]);; ?>

            </div>
          </div>

          <div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label('status', __( 'Status' ) ); ?>

            </div>
            <div class="col-lg-10">
              <label class="switch switch-label switch-pill switch-primary">
                <?php if($language->status == 1): ?>
                    <?php echo Form::checkbox('status', '1', true);; ?>

                  <?php else: ?>
                    <?php echo Form::checkbox('status', false); ?>

                <?php endif; ?>
                 
              </label>
            </div>
          </div>

          <div class="card-footer clearfix">
                    <div class="row">
                        <div class="col">
                            <a class="btn btn-danger btn-sm" href="<?php echo url('/admin/language');; ?>">Cancel</a>
                        </div>
                        <div class="col text-right">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>

        <?php echo Form::close(); ?>

        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\globalgrant\resources\views/admin/language/edit.blade.php ENDPATH**/ ?>