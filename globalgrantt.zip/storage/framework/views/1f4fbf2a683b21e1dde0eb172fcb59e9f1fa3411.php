 
<?php $__env->startSection('content'); ?>
<main class="main-content">
				<div class="breadcrumbs">
					<div class="container">
						<a href="/">Home</a>
						<span>About Us</span>
					</div>
				</div>

				<div class="page">
					<div class="fullwidth-block">
						<div class="container">
							<h1 class="entry-title">Why you should choose us?</h1>
							<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>
							
							<div class="features">
								<div class="feature-numbered">
									<div class="num">1</div>
									<h2 class="feature-title">Proin tempus</h2>
									<p> Proin tempus velit dui eu lobortis justo laoreet nec phasellus luctus elit neque eu aliquam velit dignissim donec porttitor.</p>
								</div>
								<div class="feature-numbered">
									<div class="num">2</div>
									<h2 class="feature-title">Proin tempus</h2>
									<p> Proin tempus velit dui eu lobortis justo laoreet nec phasellus luctus elit neque eu aliquam velit dignissim donec porttitor.</p>
								</div>
								<div class="feature-numbered">
									<div class="num">3</div>
									<h2 class="feature-title">Proin tempus</h2>
									<p> Proin tempus velit dui eu lobortis justo laoreet nec phasellus luctus elit neque eu aliquam velit dignissim donec porttitor.</p>
								</div>
								<div class="feature-numbered">
									<div class="num">4</div>
									<h2 class="feature-title">Proin tempus</h2>
									<p> Proin tempus velit dui eu lobortis justo laoreet nec phasellus luctus elit neque eu aliquam velit dignissim donec porttitor.</p>
								</div>
							</div>
						</div> <!-- .container -->
					</div> <!-- .fullwidth-block -->

					<div class="fullwidth-block" data-bg-color="#f1f1f1">
						<div class="container">
							<h2 class="section-title">The history</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut vitae leo ornare, fermentum libero eu, pharetra ante. Nunc consectetur pharetra tincidunt. Maecenas eget mattis ipsum. Quisque libero nisi, maximus id mauris non, imperdiet lacinia purus. Quisque a scelerisque quam, a finibus lectus.</p> 

							<p>Duis luctus a magna luctus elementum. Integer scelerisque, turpis eu placerat elementum, libero risus sodales lacus, ac vulputate quam dui eget risus. Cras vel luctus urna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Interdum et malesuada fames ac ante ipsum primis in faucibus. Phasellus luctus varius massa, ac faucibus sem posuere sit amet. Nunc nec fermentum mi. Etiam ultricies sit amet turpis vitae iaculis. Sed eget sem turpis. Morbi sodales nisi sem, pretium volutpat lectus ornare quis. Aenean vel ante enim.</p>

							<p>Nam posuere purus vitae est sollicitudin placerat. Praesent posuere porta dignissim. Phasellus viverra, urna a convallis tincidunt, ante mi tempor turpis, nec tempor mauris ligula ut sapien. Etiam euismod mi eu ante mollis commodo. Suspendisse porta nisi vitae dui hendrerit, eget ornare orci semper. Phasellus pharetra, erat sit amet rutrum porttitor, est eros consectetur elit, molestie consequat erat tellus in dui. Vestibulum a vehicula sem. Nullam commodo quis purus in volutpat. Integer semper lacus a lorem efficitur auctor. Curabitur tincidunt, ligula non ultrices eleifend, felis leo ultrices quam, vitae congue risus dui a justo. Phasellus dapibus justo lacus, eget scelerisque libero iaculis sed. Maecenas ullamcorper sit amet dui nec efficitur.</p>
						</div> <!-- .container -->
					</div> <!-- .fullwidth-block -->

					<div class="fullwidth-block">
						<div class="container">
							<h2 class="section-title">Our Team</h2>

							<div class="row">
								<div class="col-xs-12 col-sm-6 col-md-3">
									<div class="team">
										<figure class="team-image"><img src="frontend/dummy/team-1.jpg" alt=""></figure>
										<h2 class="team-name">Jessica Brown</h2>
										<small class="team-title">CEO</small>
										<div class="social-links">
											<a href="#"><i class="fa fa-facebook"></i></a>
											<a href="#"><i class="fa fa-twitter"></i></a>
											<a href="#"><i class="fa fa-google-plus"></i></a>
											<a href="#"><i class="fa fa-pinterest"></i></a>
										</div>
									</div> <!-- .team -->
								</div> <!-- .col-md-3 -->
								<div class="col-xs-12 col-sm-6 col-md-3">
									<div class="team">
										<figure class="team-image"><img src="frontend/dummy/team-2.jpg" alt=""></figure>
										<h2 class="team-name">Jeremy Stuart</h2>
										<small class="team-title">Managing Director</small>
										<div class="social-links">
											<a href="#"><i class="fa fa-facebook"></i></a>
											<a href="#"><i class="fa fa-twitter"></i></a>
											<a href="#"><i class="fa fa-google-plus"></i></a>
											<a href="#"><i class="fa fa-pinterest"></i></a>
										</div>
									</div> <!-- .team -->
								</div> <!-- .col-md-3 -->
								<div class="col-xs-12 col-sm-6 col-md-3">
									<div class="team">
										<figure class="team-image"><img src="frontend/dummy/team-3.jpg" alt=""></figure>
										<h2 class="team-name">Sarah Johnson</h2>
										<small class="team-title">Public Relation</small>
										<div class="social-links">
											<a href="#"><i class="fa fa-facebook"></i></a>
											<a href="#"><i class="fa fa-twitter"></i></a>
											<a href="#"><i class="fa fa-google-plus"></i></a>
											<a href="#"><i class="fa fa-pinterest"></i></a>
										</div>
									</div> <!-- .team -->
								</div> <!-- .col-md-3 -->
								<div class="col-xs-12 col-sm-6 col-md-3">
									<div class="team">
										<figure class="team-image"><img src="frontend/dummy/team-4.jpg" alt=""></figure>
										<h2 class="team-name">Paul ferguson</h2>
										<small class="team-title">Consultant</small>
										<div class="social-links">
											<a href="#"><i class="fa fa-facebook"></i></a>
											<a href="#"><i class="fa fa-twitter"></i></a>
											<a href="#"><i class="fa fa-google-plus"></i></a>
											<a href="#"><i class="fa fa-pinterest"></i></a>
										</div>
									</div> <!-- .team -->
								</div> <!-- .col-md-3 -->
							</div> <!-- .row -->
						</div> <!-- .container -->
					</div> <!-- .fullwidth-block -->
				</div> <!-- .page -->
			</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\globalgrant\resources\views\about.blade.php ENDPATH**/ ?>