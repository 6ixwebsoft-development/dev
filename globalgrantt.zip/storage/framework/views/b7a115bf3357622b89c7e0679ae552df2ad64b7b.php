<?php $__env->startSection('content'); ?>
<main class="main-content">
	<div class="breadcrumbs">
		<div class="container">
			<a href="/">Home</a>
			<span>Contact</span>
		</div>
	</div>

	<div class="page">
		<div class="container">
			<div class="map"></div>

			<div class="row">
				<div class="col-md-3">
					<h2 class="section-title text-left">Address</h2>

					<div class="contact-detail">
						<address>
							<p>Company Name INC. <br>
								523 Burt Street, Omaha</p>

							<p>Phone: +1 823 424 9134
								info@company.com</p>
						</address>
					</div>
				</div>
				<div class="col-md-9">
					<h2 class="section-title text-left">Contact form</h2>
					<form action="#" class="contact-form">
						<div class="row">
							<div class="col-md-4"><input type="text" placeholder="Your name..."></div>
							<div class="col-md-4"><input type="text" placeholder="Email..."></div>
							<div class="col-md-4"><input type="text" placeholder="Website..."></div>
						</div>

						<textarea  placeholder="Message..."></textarea>

						<p class="text-right">
							<input type="submit" value="Send message">
						</p>
					</form>


				</div>
			</div>
		</div>
	</div> <!-- .page -->
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\globalgrant\resources\views\contact-us.blade.php ENDPATH**/ ?>