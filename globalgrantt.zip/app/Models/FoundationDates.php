<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoundationDates extends Model
{
    //
	protected $table = 'gg_foundation_dates';
    protected $guarded = [];
}
