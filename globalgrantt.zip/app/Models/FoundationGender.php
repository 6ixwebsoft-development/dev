<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoundationGender extends Model
{
    //
	protected $table = 'gg_foundation_gender';
    protected $guarded = [];
}
