<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoundationInstructions extends Model
{
    //
	protected $table = 'gg_foundation_instructions';
    protected $guarded = [];
}
