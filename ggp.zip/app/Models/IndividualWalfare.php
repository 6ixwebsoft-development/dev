<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualWalfare extends Model
{
    protected $table = 'individual_welfare';
}
