<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
	protected $table = 'paymentmood';
   // protected $fillable = ['module_id', 'field_name', 'field_type', 'status'];
}
