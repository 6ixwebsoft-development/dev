<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Libraryips extends Model
{
    protected $table = 'libraryips';
}
