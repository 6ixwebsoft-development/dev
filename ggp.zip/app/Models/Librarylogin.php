<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Librarylogin extends Model
{
   protected $table = 'librarylogin';
}
