<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualResearch extends Model
{
    protected $table = 'individual_research';
}
