<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CmsPages extends Model
{
    protected $table = 'gg_cms_pages';
    protected $guarded = [];
    
}
