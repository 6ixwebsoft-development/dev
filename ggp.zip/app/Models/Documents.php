<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Documents extends Model
{
   protected $table = 'tbl_images';
}
