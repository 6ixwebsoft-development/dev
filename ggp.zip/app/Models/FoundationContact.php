<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoundationContact extends Model
{
    //
	protected $table = 'gg_foundation_contact';
    protected $guarded = [];
}
