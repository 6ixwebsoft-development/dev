<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SearchCount extends Model
{
    //
	protected $table = 'gg_search_count';
    protected $guarded = [];
}
