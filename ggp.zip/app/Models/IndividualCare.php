<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualCare extends Model
{
     protected $table = 'individual_care';
}
