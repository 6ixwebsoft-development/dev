<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class LibraryGroup extends Model
{
    protected $table = 'gg_user_search_save';
}
