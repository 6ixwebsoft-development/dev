<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualContact extends Model
{
   protected $table = 'individual_contact';
}
