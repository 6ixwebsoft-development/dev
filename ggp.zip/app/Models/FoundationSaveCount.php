<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoundationSaveCount extends Model
{
    //
	protected $table = 'gg_foundation_save_count';
    protected $guarded = [];
}
