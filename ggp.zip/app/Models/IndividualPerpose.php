<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IndividualPerpose extends Model
{
    protected $table = 'individual_purposelist';
}
