<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class LibraryContact extends Model
{
   protected $table = 'library_contact';
}
