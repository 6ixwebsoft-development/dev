<?php

namespace App\Admin\models;

use Illuminate\Database\Eloquent\Model;

class DocumentsController extends Model
{
    //
}
