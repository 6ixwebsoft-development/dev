<?php

namespace App\Admin\models;

use Illuminate\Database\Eloquent\Model;

class Documents extends Model
{
    //
}
