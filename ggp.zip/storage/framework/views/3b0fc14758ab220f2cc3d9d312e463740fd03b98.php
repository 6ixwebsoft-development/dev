 <?php $__env->startSection('breadcrumb'); ?>
<!-- Breadcrumb-->
<ol class="breadcrumb">
	<li class="breadcrumb-item">Home</li>
	<li class="breadcrumb-item"> <a href="#">Admin</a>
	</li>
	<li class="breadcrumb-item active">Dashboard</li>
	<!-- Breadcrumb Menu-->
	<li class="breadcrumb-menu d-md-down-none">
		<div class="btn-group" role="group" aria-label="Button group">
			<a class="btn" href="#"> <i class="icon-speech"></i>
			</a>
			<a class="btn" href="./"> <i class="icon-graph"></i>  Dashboard</a>
			<a class="btn" href="#"> <i class="icon-settings"></i>  Settings</a>
		</div>
	</li>
</ol>
<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-sm-5">
						<h4 class="card-title mb-0">
                    	Create Foundation<small class="text-muted">Foundation Management</small>
                		</h4>
					</div>
					<!--col-->
					<div class="col-sm-7">
						
					</div>
					<!--col-->
				</div>
				<!--row-->
				<hr>
					<?php if(count($errors) > 0): ?>
						<div class="alert alert-danger alert-dismissible fade show" role="alert">
							<ul id="login-validation-errors" class="validation-errors">
								<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li class="validation-error-item"><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div><hr>
					<?php endif; ?>
				<?php echo Form::open(array('url' => 'admin/foundation/store')); ?>

					
					<div class="row">
						<div class="col-12">
	                        <div class="nav nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
	                            <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="false">Basic Info</a>
	                            <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Criteria</a>
	                     
	                        </div>
	                    </div>
	                    <div class="col-12">
	                        <div class="tab-content " class="bottom_style" id="v-pills-tabContent">
	                            <div class="tab-pane fade active show" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
	                            <div class="row">
                                    <div class="col-md-6">

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('name', __( 'Name' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                               <?php echo Form::text('name', null, ['class' => 'form-control', '', 'placeholder' => __( 'Name' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('sort-name', __( 'Sort Name' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                                    <?php echo Form::text('sort_name', null, ['class' => 'form-control', '', 'placeholder' => __( 'Sort Name' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('source', __( 'Source' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                                    <?php echo Form::text('source', null, ['class' => 'form-control', '', 'placeholder' => __( 'Source' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('type', __( 'Type' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('type', null, ['class' => 'form-control', '', 'placeholder' => __( 'Type' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('availability', __( 'Availability' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                               
                                                <?php echo Form::select('availability', array('1' => 'Yes', '2' => 'No'), '1', ['class' => 'form-control']);; ?>

                                                    
                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div>

                                    <div class="col-md-6"> 
                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('status', __( 'Status' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                                <?php echo Form::select('status', array('Active' => 'Active', 'Expired' => 'Expired', 'NoAppl' => 'NoAppl', 'NoGG' => 'NoGG', 'NoAdr' => 'NoAdr', 'Double' => 'Double'), '1', ['class' => 'form-control']);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('language', __( 'Language' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                                <?php echo Form::select('language_id', $language, '[]', ['class' => 'form-control']);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('admin', __( 'Admin' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                                    <?php echo Form::text('admin', null, ['class' => 'form-control', '', 'placeholder' => __( 'Admin' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('asset', __( 'Assets' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('asset', null, ['class' => 'form-control', '', 'placeholder' => __( 'Assets' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('org-no', __( 'Org. No' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('org_no', null, ['class' => 'form-control', '', 'placeholder' => __( 'Org No' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('remarks', __( 'Remarks' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::textarea('remarks', null, ['class' => 'form-control', '', 'placeholder' => __( 'remarks' ) ]);; ?>


                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div> 
                                    <div class="col-md-12">
                                        <h4>Public Details</h4>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('email', __( 'Email' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                                <?php echo Form::email('email', null, ['class' => 'form-control', '', 'placeholder' => __( 'Email' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('mobile', __( 'Mobile' ) . ''); ?>

											</div>

                                            <div class="col-md-9">

                                                <?php echo Form::text('mobile', null, ['class' => 'form-control', '', 'placeholder' => __( 'Mobile' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('address-1', __( 'Address 1' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('address_1', null, ['class' => 'form-control', '', 'placeholder' => __( 'Address-1' ) ]);; ?>

                                                
                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('address-2', __( 'Address Line 2' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('address_2', null, ['class' => 'form-control', '', 'placeholder' => __( 'Address-2' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('address-3', __( 'Address line 3' ) . ':*'); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('address_3', null, ['class' => 'form-control', '', 'placeholder' => __( 'Address-3' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('phone', __( 'Phone' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('phone', null, ['class' => 'form-control', '', 'placeholder' => __( 'Phone' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                        
                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('zip-code', __( 'Zip Code' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('zipcode', null, ['class' => 'form-control', '', 'placeholder' => __( 'Zip Code' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('website', __( 'Website' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                                <?php echo Form::text('website', null, ['class' => 'form-control', '', 'placeholder' => __( 'Website' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                    </div>

                                    <div class="col-md-12">
                                        <h4>Private Details</h4>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('c-email', __( 'Email' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::email('c_email', null, ['class' => 'form-control', '', 'placeholder' => __( 'Email' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('c-phone', __( 'Phone' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('c_phone', null, ['class' => 'form-control', '', 'placeholder' => __( 'Phone' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('c-address', __( 'Address' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('c_address', null, ['class' => 'form-control', '', 'placeholder' => __( 'Address' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                        
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('c-name', __( 'Name' ) . ''); ?>

											</div>

                                            <div class="col-md-9">
                                            	<?php echo Form::text('c_name', null, ['class' => 'form-control', '', 'placeholder' => __( 'Name' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->

                                        <div class="form-group row">
                                            <div class="col-lg-3">
												<?php echo Form::label('c-mobile', __( 'Mobile' ) . ''); ?>

											</div>
                                            <div class="col-md-9">
                                                <?php echo Form::text('c_mobile', null, ['class' => 'form-control', '', 'placeholder' => __( 'Mobile' ) ]);; ?>

                                            </div><!--col-->
                                        </div><!--form-group-->
                                    </div>
                                </div>
								
								 <!-- <div class="col-xl-12 col-md-12 col-sm-12">
									<div class="card">
									  <div class="card-header bg-info">Videos, Photos, Social Media</div>
									  <div class="card-body col-xl-12 ">
									 
									  <div class="form-inline">
										<div class="col-xl-3 col-md-12 col-sm-12">
											<div class="form-group row">
												<?php echo Form::label('Type', __( 'Type' ) . ':', [ 'class' => 'col-sm-4 col-form-label']); ?>

												<div class="col-sm-8">								 
													 <?php echo Form::select('videotype[]', (['0' => 'Facebook','1' => 'LinkedIn','2' => 'Youtube'] ),[], ['class' => 'form-control']); ?>

												</div>
											</div>
										</div>
										
										<div class="col-xl-6 col-md-12 col-sm-12">
											<div class="form-group row">
												<?php echo Form::label('Url', __( 'Url' ) . ':', [ 'class' => 'col-sm-4 col-form-label']); ?>

												<div class="col-sm-8">								 
													<?php echo Form::text('video_url[]', null, ['class' => 'form-control', 'value'=>'http://',  ]);; ?>

												</div>
											</div>
										</div>
										
											<div class="col-xl-3 col-md-12 col-sm-12">
												<div class="form-group row">
													<div class="col-sm-4">
														<a class="btn btn-primary add_buttonvideo" value="add">Add</a>
													</div>
													
												</div>
											</div>
										
										</div><br>
										
										<div class="field_wrappervideo "></div>	
										</div>
									  </div>						 
									</div>-->
						
	                            </div>
                            	<div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                            		<div class="row">
                                    <div class="col-md-2">
                                        <div class="f_purpose">
                                            <h4>Purpose</h4>
                                            <?php echo Form::select('purpose_ids[]', $purpose, '', ['class' => 'form-control', 'multiple' => 'multiple']);; ?>

                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="f_gender">
                                            <h4>Genders</h4>
                                            <?php echo Form::select('gender_ids[]', $gender, '', ['class' => 'form-control', 'multiple' => true]);; ?>

                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="card">
											<div class="card-header bg-info">Age</div>
												<div class="f_age"><br>    
													<div class="form-group row">
														<div class="col-lg-2">
															<?php echo Form::label('age-from', __( 'From' ) . ''); ?>

														</div>

														<div class="col-md-3">
															<?php echo Form::text('age_from[]', null, ['class' => 'form-control', 'maxlength'=>'2', 'placeholder' => __( 'Age From' ) ]);; ?>

														</div><!--col-->
												   
														<div class="col-lg-2">
															<?php echo Form::label('age-to', __( 'To' ) . ''); ?>

														</div>

														<div class="col-md-3">
															<?php echo Form::text('age_to[]', null, ['class' => 'form-control','maxlength'=>'2', 'placeholder' => __( 'Age To' ) ]);; ?>

														</div><!--col-->
														<div class="col-sm-2">
															<a class="btn btn-primary add_buttonage" value="add">Add</a>
														</div>
													</div><!--form-group-->
													<div class="field_wrapperage "></div>	
												</div>
											</div>
										</div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="f_gender">
                                            <h4>Subject</h4>
                                            <?php echo Form::select('subject_ids[]', $subject, '', ['class' => 'form-control', 'multiple' => 'multiple']);; ?>

                                        </div>
                                    </div>
										<br>
									<div class="row">
										 <div class="col-md-12">
											<div class="card">
											  <div class="card-header bg-info">Location</div>
											  <div class="card-body">
											 
											  <div class="">
													<div class="">
														<div class="f_gender">
															<h4>Location</h4>
															<div class="row">
																<div class="col-md-2">
																	<?php echo Form::label('country-block', __( 'Country Block' ) . ''); ?>

																	<?php echo Form::select('country_block[]', $blocks_arr, '', ['class' => 'form-control', 'id' => 'countryBlock']);; ?>

																</div><!--col-->
																<div class="col-md-2">
																	<?php echo Form::label('country', __( 'Country' ) . ''); ?>

																	<?php echo Form::select('country[]', $country_arr, '', ['class' => 'form-control', 'id' => 'countries','onchange' => 'getRegion();']);; ?>

																</div><!--col-->
																<div class="col-md-2">
																	<?php echo Form::label('region', __( 'Region' ) . ''); ?>

																	<?php echo Form::select('region[]', $region_arr, '', ['class' => 'form-control regiondata','id' => 'regionid','onchange' => 'getCity();']);; ?>

																</div><!--col-->
																<div class="col-md-2">
																	<?php echo Form::label('city', __( 'City' ) . ''); ?>

																	<?php echo Form::select('city[]', $city_arr, '', ['class' => 'form-control citydata', 'id' => 'cityid']);; ?>

																</div><!--col-->
																<div class="col-md-2">
																	<?php echo Form::label('parish[]', __( 'Parish' ) . ''); ?>

																	
																	<?php echo Form::text('parish', null, ['class' => 'form-control ', '', 'placeholder' => __( 'Parish' ) ]);; ?>

																</div><!--col-->
																<div class="col-md-2" style="margin-top: 2%;">
																	<a class="btn btn-primary add_buttonlocation form-control" value="add">Add</a>
																</div><!--col-->
															</div><!--row-->

														</div>
														</div>
												
												</div><br>
												<div class="field_wrapperlocation"></div>	
												</div>
											  </div>						 
											</div>
										</div>

                                    <!-- application dates -->
                                    <div class="col-md-12">
										<div class="card">
											  <div class="card-header bg-info">Application Dates</div>
												<div class="card-body">
													<div class="app_dates">                                         
														<div class="row">
															<div class="col-md-6">
																<div class="row">
																	<div class="col-md-4">
																		<?php echo Form::label('app_start_day', __( 'Application Start' ) . ''); ?>

																	</div>
																	<div class="col-md-3">
																		<?php echo Form::select('apply_start_month',$months, '', ['class' => 'form-control']);; ?>

																	</div>
																	<div class="col-md-3">
																		<?php echo Form::text('apply_start_day', null, ['class' => 'form-control', '' ]);; ?>

																	</div>

																</div> 
																
															</div>
															<div class="col-md-6">
																<div class="row">
																	<div class="col-md-4">
																		<?php echo Form::label('app_end_day', __( 'Application End' ) . ''); ?>

																	</div>
																	<div class="col-md-3">
																		<?php echo Form::select('apply_end_month',$months, '', ['class' => 'form-control']);; ?>

																	</div>
																	<div class="col-md-3">
																		<?php echo Form::text('apply_end_day', null, ['class' => 'form-control', '' ]);; ?>

																	</div>

																</div> 
															</div>
														</div>
														
														
													</div>
												</div>
											</div>
										</div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="purpose-details">
                                            <h4>Purpose</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('purpose_detail', null, ['class' => 'form-control core_quill', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="purpose-details">
                                            <h4>Who Can Apply</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('who_can_apply', null, ['class' => 'form-control', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="purpose-details">
                                            <h4>Application Details</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('application_details', null, ['class' => 'form-control', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>

                                        <div class="purpose-details">
                                            <h4>Misc</h4>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <?php echo Form::textarea('misc', null, ['class' => 'form-control', '' ]);; ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
								  </div>
                            	</div>
                            </div>
                        </div>
					</div>


					<div class="card-footer clearfix">
		                <div class="row">
		                    <div class="col">
		                        <a class="btn btn-danger btn-sm" href="<?php echo url('/admin/foundation');; ?>">Cancel</a>
		                    </div>
		                    <div class="col text-right">
		                        <button type="submit" class="btn btn-primary">Save</button>
		                    </div>
		                </div>
		            </div>

				<?php echo Form::close(); ?>

		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/admin/foundation/create.blade.php ENDPATH**/ ?>