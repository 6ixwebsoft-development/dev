 
<?php $__env->startSection('content'); ?>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
.textset{
	 padding-left: 40px;
}

</style>
<div class="fund_email" style="position: relative;">
	<div class="mail-modal">
		<div class="modal-overlay"></div>
		<div class="modal-wrapper modal-transition">
			<div class="modal-header">
				<button class="modal-close mail-toggle">
					<i class="fa fa-times"></i>
				</button>
				<h2 class="modal-heading foundation-name"></h2>
			</div>

			<div class="modal-body">
				<div class="modal-content">
					<?php echo Form::open(array('url' => 'fund-search-mail-send')); ?>


						<?php echo Form::text('email', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => __( 'Email' ) ]);; ?>

						<button type="submit" class="btn btn-primary">Send Email</button>
						<div class="mail-body"></div>
					<?php echo Form::close(); ?>


				</div>
			</div>
		</div>
	</div >
</div>
<div class="container">
  <h3 class="text-primary">Member Page</h3>
  
  <div class="row">
   <?php echo $__env->make('customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9 col-md-6 col-lg-9">
	
		<?php if($message = Session::get('message')): ?>
			<div class="alert <?php echo e($message['class']); ?> alert-dismissible">
			  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			  <?php echo e($message['msg']); ?>

			</div>
		 <?php endif; ?>
		<div class="col-sm-12">
			<h3 class="text-primary">YOUR SAVED FUND RECORDS .</h3>
		</div>
		
		<br>
		<hr style="width: 100%; border-bottom: 2px dotted #108cca;">
		<h4 class="text-primary">If you don't see the names of the funds you saved,<br>register your library card number<br>under tab REGISTER YOUR LIBRARY CARD.</h4>
		
		<div class="col-sm-6 pull-left">
			<a href="#" id="search_email" class="btn btn-primary"><?php echo e(__('word.'.strtolower('e-mail'))); ?></a>
		</div>
		<div class="col-sm-6 ">
			<a href="/search-foundation" id="search_email" class="btn btn-primary pull-right">Seaech foundation</a>
		</div>
		<div class="col-sm-12">
			<table class="table table-bordered " id="">
				<thead>
				<tr>
					<th><input type="checkbox" name="" id="selectAll"></th>
					<th>ID#</th>
					<th>Contact person</th>
					<th>Action</th>
				</tr>
				</thead>
					<?php if(!empty($foundation)): ?>
						<?php $__currentLoopData = $foundation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $found): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><input type="checkbox" name="foundatoin_check" id="checked_foundation" value="<?php echo e($found->id); ?>"></td>
								<td><?php echo e($found->id); ?></td>
								<?php if($found->display == 0): ?>
									<td></td>
								<?php else: ?>
									<td><?php echo e($found->name); ?></td>
								<?php endif; ?>
								<td><a onclick="return confirm('Are you want to delete?')" href="<?php echo e(url('delete-save-found').'/'.$found->id); ?>"><span class="glyphicon glyphicon-trash" ></span></a></td>
							</tr>
							
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<tbody>
					<tr>
						<td colspan="8">No foundation found.</td>
					</tr>
					</tbody>
					<?php endif; ?>
					</table>
				</div>
			</div>
		  </div>
		  <br>
		</div>
		
<script>
	function showFromBox(){
		$(".datashow").hide();
		$(".formBox").show();
	}
	
	function hideFromBox(){
		$(".formBox").hide();
		$(".datashow").show();
	}
	
	
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/customer/foundation.blade.php ENDPATH**/ ?>