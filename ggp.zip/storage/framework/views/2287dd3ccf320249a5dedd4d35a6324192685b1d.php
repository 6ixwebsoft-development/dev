<div class="col-sm-3 col-md-6 col-lg-3" >
		<ul class="list-group">
			<li class="list-group-item"><a href="<?php echo e(url('/customer/edit/foundations')); ?>">YOUR SAVED FUND RECORDS</a></li>
			<li class="list-group-item"><a href="<?php echo e(url('/customer/edit/basicinfo')); ?>">YOUR NAME</a></li>
			<li class="list-group-item"><a href="<?php echo e(url('/customer/edit/contactinfo')); ?>">YOUR CONTACT DETAILS</a></li>
			<li class="list-group-item"><a href="<?php echo e(url('/customer/edit/admin')); ?>"> YOUR LOGIN DETAILS</a></li>
			<li class="list-group-item"><a href="<?php echo e(url('/customer/edit/cardnumber')); ?>"> - REGISTER YOUR LIBRARY CARD</a></li>
			
		  </ul>
    </div>
<?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/customer/sidebar.blade.php ENDPATH**/ ?>