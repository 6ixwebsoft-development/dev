<?php $__env->startSection('content'); ?>
<main class="main-content">
	<?php $__currentLoopData = $page_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="breadcrumbs">
		<div class="container">
			<a href="/">Home</a>
			<span><?php echo e($page->title); ?></span>
		</div>
	</div>

	<div class="page">
		<div class="container">
			<h2><?php echo $page->title; ?></h2>
			<!--<strong>Description:</strong> -->
			<p><?php echo $page->short_description; ?></p>
			<strong>Content Block:</strong>
			<?php $__currentLoopData = $page_blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page_block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<p><?php echo $page_block->text; ?></p>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<!-- <h3>Page Meta</h3>
			<?php $__currentLoopData = $page_meta_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page_meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<strong>Meta Title:</strong>
			<p><?php echo $page_meta->meta_title; ?></p>
			<strong>Meta Keyword:</strong>
			<p><?php echo $page_meta->meta_keyword; ?></p>
			<strong>Meta Description:</strong>
			<p><?php echo $page_meta->meta_description; ?></p> -->
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div> <!-- .page -->
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/pages.blade.php ENDPATH**/ ?>