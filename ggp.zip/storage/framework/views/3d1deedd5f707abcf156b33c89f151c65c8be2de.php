<?php $__env->startSection('breadcrumb'); ?>

  <!-- Breadcrumb-->

  <ol class="breadcrumb">

    <li class="breadcrumb-item">Home</li>

    <li class="breadcrumb-item">

      <a href="#">Admin</a>

    </li>

    <li class="breadcrumb-item active">Dashboard</li>

    <!-- Breadcrumb Menu-->

    <li class="breadcrumb-menu d-md-down-none">

      <div class="btn-group" role="group" aria-label="Button group">

        <a class="btn" href="#">

        <i class="icon-speech"></i>

        </a>
			<?php if($errors->any()): ?>
			<?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

			<?php endif; ?>
        <a class="btn" href="./">

        <i class="icon-graph"></i>  Dashboard</a>

        <a class="btn" href="#">

        <i class="icon-settings"></i>  Settings</a>

      </div>

    </li>

  </ol>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>  

  <div class="row">
    <div class="col-lg-12">

      <div class="card">

        <div class="card-body">

          <div class="row">

              <div class="col-sm-5">

                  <h4 class="card-title mb-0">

                      Product Management <small class="text-muted">Product Add</small>


                  </h4>

              </div><!--col-->
          </div><!--row-->

          <hr>
		  
		    <?php if(count($errors) > 0): ?>
				<div class="alert alert-danger alert-dismissible fade show" role="alert">
					<ul id="login-validation-errors" class="validation-errors">
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="validation-error-item"><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
			<?php endif; ?>

       <?php echo Form::open(array('route' => array('admin.product.update', $product->id))); ?>


          

          <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Product Name', __( 'Product Name' ).':*', [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::text('productname', $product->productname, ['class' => 'form-control', '', 'placeholder' => __( 'Enter Product Name' ) ]);; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Available Language', __( 'Available Language' ) . ':*', [ 'class' => 'col-form-label']); ?>

					  

					</div>

					<div class="col-lg-12">

					 
					 
					  
					  <?php echo Form::select('languageid', $language,$product->languageid, ['class' => 'form-control']); ?>


					</div>
				</div>

          </div>
		  
		  <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Office', __( 'Office' ) . ':*', [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					 <?php echo Form::select('officeid', $office,$product->officeid, ['class' => 'form-control','' ]  );; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Type', __( 'Type' ) . ':*', [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::select('typeid', array('1' => 'Ongoing monthly subscription', '2' => 'Stora Fondboken','3' => 'Lists', '4' => 'Services'),null, ['class' => 'form-control','' ]  );; ?>


					</div>
				</div>

          </div>
		  
		  <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Category', __( 'Category' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">
					    <?php echo e(Form::radio('category', 'auto' , false)); ?>  Auto-list  
						<?php echo e(Form::radio('category', 'custom' , false)); ?> Custom-list
						<?php echo e(Form::radio('category', 'na' , false)); ?> N/A

					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Currency', __( 'Currency' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					   <?php echo Form::text('currency', 'SEK', ['class' => 'form-control', '','value' =>'SEK' ,'readonly']);; ?>


					</div>
				</div>

          </div>
		  
		  <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Price*', __( 'Price*' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::text('price', $product->price, ['class' => 'form-control price', '', 'placeholder' => __( 'Enter Price' ) ]);; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Subscription?', __( 'Subscription?' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">
					<?php if($product->subscription == 1 ): ?>
						<?php echo e(Form::radio('subscription', '1' ,true)); ?>  Yes
					 <?php echo e(Form::radio('subscription', '0' , false)); ?> No
					<?php else: ?>
					<?php echo e(Form::radio('subscription', '1' , false)); ?>  Yes
					 <?php echo e(Form::radio('subscription', '0' , true)); ?> No
					<?php endif; ?>
						
					 

					</div>
				</div>

          </div>
		  
		  <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Display In?', __( 'Display In?' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">
					<?php if($product->display == 1 ): ?>
						 <?php echo e(Form::radio('display', '1' , true)); ?>  Backend Only
						 <?php echo e(Form::radio('display', '0' , false)); ?> Both Frontend & Backend
					<?php else: ?>
						<?php echo e(Form::radio('display', '1' , false)); ?>  Backend Only
						<?php echo e(Form::radio('display', '0' , true)); ?> Both Frontend & Backend
					<?php endif; ?>
					
					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Payment Mode', __( 'Payment Mode' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::select('paymentmood', $payment,$product->paymentmood,['class' => 'form-control','' ]  );; ?>


					</div>
				</div>

          </div>
		
		<div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Discount Label', __( 'Discount Label' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::text('discountlabel', $product->discountlabel, ['class' => 'form-control', '', 'placeholder' => __( 'Enter Discount Label' ) ]);; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Discount Amount', __( 'Discount Amount' ), [ 'class' => 'col-form-label']); ?>

					  

					</div>

					<div class="col-lg-12">

					 
					  <?php echo Form::text('discountamount', $product->discountamount, ['class' => 'form-control disamt', '', 'placeholder' => __( 'Enter Discount Amount' ) ]);; ?>


					</div>
				</div>

          </div>
			
			<div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('VAT Label', __( 'VAT Label' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::text('vatlabel', $product->vatlabel, ['class' => 'form-control', '', 'placeholder' => __( 'Enter VAT Label' ) ]);; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('VAT %', __( 'VAT %' ), [ 'class' => 'col-form-label']); ?>

					  

					</div>

					<div class="col-lg-12">

					 
					  <?php echo Form::text('vatamount', $product->vatamount, ['class' => 'form-control vattax', '', 'placeholder' => __( 'Enter VAT %' ) ]);; ?>


					</div>
				</div>

          </div>
		  
		  
		  <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Freight Label', __( 'Freight Label' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::text('freightlabel', $product->freightlabel, ['class' => 'form-control', '', 'placeholder' => __( 'Enter Freight Label' ) ]);; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Freight Charge', __( 'Freight Charge' ), [ 'class' => 'col-form-label']); ?>

					  

					</div>

					<div class="col-lg-12">

					 
					  <?php echo Form::text('freightamount', $product->freightamount, ['class' => 'form-control framt', '', 'placeholder' => __( 'Enter Freight Charge' ) ]);; ?>


					</div>
				</div>

          </div>
		  
		   <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Freight Tax Label', __( 'Freight Tax Label' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::text('freighttaxlabel', $product->freighttaxlabel, ['class' => 'form-control', '', 'placeholder' => __( 'Enter Freight Tax Label' ) ]);; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Freight Tax %', __( 'Freight Tax %' ), [ 'class' => 'col-form-label']); ?>

					  

					</div>

					<div class="col-lg-12">

					 
					  <?php echo Form::text('freighttax', $product->freighttax, ['class' => 'form-control frtax', '', 'placeholder' => __( 'Enter Freight Tax %' ) ]);; ?>


					</div>
				</div>

          </div>
		  
		  <div class="form-group row">

				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Total Amount', __( 'Total Amount' ), [ 'class' => 'col-form-label']); ?>


					</div>

					<div class="col-lg-12">

					  <?php echo Form::text('totalprice', $product->totalprice, ['class' => 'form-control grandtotal', '', 'placeholder' => __( '' ),'readonly' ]);; ?>


					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-lg-4">

					  <?php echo Form::label('Description', __( 'Description' ), [ 'class' => 'col-form-label']); ?>

					  

					</div>

					<div class="col-lg-12">

					 
					  <?php echo Form::textarea('description', $product->description, ['class' => 'form-control', '', 'placeholder' => __( 'Write Description...' ) ]);; ?>


					</div>
				</div>

          </div>
		  
		 

          <div class="card-footer clearfix">

            <div class="row">

                <div class="col">

                    <a class="btn btn-danger btn-sm" href="<?php echo url('/admin/products');; ?>">Cancel</a>

                </div>

                <div class="col text-right">

                    <button type="submit" class="btn btn-primary">Save</button>

                </div>

            </div>

        </div>



        <?php echo Form::close(); ?>


        </div>

      </div>

    </div>



  </div>

<?php $__env->stopSection(); ?>

   
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/admin/sproduct/edit.blade.php ENDPATH**/ ?>