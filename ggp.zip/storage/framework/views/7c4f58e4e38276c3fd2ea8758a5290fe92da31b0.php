 
<?php $__env->startSection('content'); ?>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
.textset{
	 padding-left: 40px;
}

</style>

 <?php if($message = Session::get('message')): ?>
      <div class="alert <?php echo e($message['class']); ?>" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong><?php echo e($message['msg']); ?></strong>
      </div>
      <?php endif; ?>

<div class="container">
  <h3 class="text-primary">Member Page</h3>
  
  <div class="row">
    <?php echo $__env->make('customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-sm-9 col-md-6 col-lg-9">
	
		<?php if($message = Session::get('message')): ?>
			<div class="alert <?php echo e($message['class']); ?> alert-dismissible">
			  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			  <?php echo e($message['msg']); ?>

			</div>
		 <?php endif; ?>
		<div class="col-sm-8">
			<h3 class="text-primary">Welcome : <?php echo e($user->name); ?></h3>
		</div>
		<div class="col-sm-4">
		</div>
		<br>
		<hr style="width: 100%; border-bottom: 2px dotted #108cca;">
		
  </div>
  <br>
</div>
<script>
	function showFromBox(){
		$(".datashow").hide();
		$(".formBox").show();
	}
	
	function hideFromBox(){
		$(".formBox").hide();
		$(".datashow").show();
	}
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/customer/index.blade.php ENDPATH**/ ?>