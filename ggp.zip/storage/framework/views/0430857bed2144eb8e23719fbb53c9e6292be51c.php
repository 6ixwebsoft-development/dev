 
<?php $__env->startSection('content'); ?>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
.textset{
	 padding-left: 40px;
}

</style>

<div class="container">
	<h3 class="text-primary">Remote Access</h3>
	<hr style="width: 100%; border-bottom: 2px dotted #108cca;">
	<div class="row">
		<div class="col-sm-8">
			<h4 class="text-primary">With a Swedish library card or an international subscription you an find all</h4>
			<p>You can log on remote to our server if your university or library is subscribed to the Global Grant Services. If your school or city is not in the list, you can search for the school / library on the Internet. Some libraries have their own pages for remote access login. For example Google "globalgrant göteborg".</p>
			<br>
			<p class="text-primary">More information about Global Grant </p>
			
			<?php if($message = Session::get('message')): ?>
			<div class="alert <?php echo e($message['class']); ?> alert-dismissible">
			  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			  <?php echo e($message['msg']); ?>

			</div>
			 <?php endif; ?>
			 <?php if(count($errors) > 0): ?>
				<div class="alert alert-danger alert-dismissible" role="alert">
					<ul id="login-validation-errors" class="validation-errors">
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="validation-error-item"><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div><hr>
			<?php endif; ?>
			
			<form class="form-horizontal" action="<?php echo e(url('/libararycard_login')); ?>" method="post">
			<?php echo csrf_field(); ?>
			
				<div class="form-group">
					<label class="col-sm-4" for="email">Select library or city:*</label>
					<div class="col-sm-8">
					  <select class="form-control" name="libarary">
						<option value="">select libarary</option>
						<?php $__currentLoopData = $library; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Library): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($Library->id); ?>"><?php echo e($Library->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					  </select>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-4" for="email">Your library card code:*</label>
					<div class="col-sm-8">
					  <input type="text" class="form-control formBox" id="librarycard" name="librarycard" value="">
					</div>
				</div>
				
				<button type="submit" class="pull-right btn btn-primary formBox" >Login</button>
				
			</div>
		</form>
	</div>
  <br>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/remote_login.blade.php ENDPATH**/ ?>