<?php $__env->startSection('breadcrumb'); ?>
  <!-- Breadcrumb-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">Home</li>
    <li class="breadcrumb-item">
      <a href="#">Admin</a>
    </li>
    <li class="breadcrumb-item active">Dashboard</li>
    <!-- Breadcrumb Menu-->
    <li class="breadcrumb-menu d-md-down-none">
      <div class="btn-group" role="group" aria-label="Button group">
        <a class="btn" href="#">
        <i class="icon-speech"></i>
        </a>
        <a class="btn" href="./">
        <i class="icon-graph"></i>  Dashboard</a>
        <a class="btn" href="#">
        <i class="icon-settings"></i>  Settings</a>
      </div>
    </li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    
    <div class="col-lg-12">
      <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-5">
                    <h4 class="card-title mb-0">
                        Role Management <small class="text-muted">Edit role</small>
                   
                    </h4>
                </div><!--col-->

               
          </div><!--row-->
          <hr>


<?php echo Form::model($role, ['method' => 'PATCH','route' => ['roles.update', $role->id]]); ?>

    <div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label('name', __( 'Name' ) . ':*'); ?>

            </div>
            <div class="col-lg-10">
            <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

        </div>
    </div>
    <!--<div class="form-group row">
            <div class="col-lg-2">
              <?php echo Form::label('permission', __( 'Permissions' ) . ':*'); ?>

            </div>
            <div class="col-lg-10">
            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label><?php echo e(Form::checkbox('permission[]', get_permission_id($value.'-index'), in_array(get_permission_id($value.'-index'), $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                <?php echo e($value->name); ?></label>
            <br/>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div> -->
	
	<?php $__currentLoopData = $controllers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="form-group row">
			
                <div class="col-lg-4">

                  <?php echo Form::label($key, __( $key ), [ 'class' => 'col-form-label']); ?>


                </div>
				
                <div class="col-lg-2">
                        <label><?php echo e(Form::checkbox('permission[]', get_permission_id($value.'-index'), in_array(get_permission_id($value.'-index'), $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                       View</label>
                </div>
				<div class="col-lg-2">
                        <label><?php echo e(Form::checkbox('permission[]', get_permission_id($value.'-create'), in_array(get_permission_id($value.'-create'), $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                       Create</label>
                </div>
				<div class="col-lg-2">
                        <label><?php echo e(Form::checkbox('permission[]', get_permission_id($value.'-edit'), in_array(get_permission_id($value.'-edit'), $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                        Update</label>
                </div>
				<div class="col-lg-2">
                        <label><?php echo e(Form::checkbox('permission[]', get_permission_id($value.'-delete'), in_array(get_permission_id($value.'-delete'), $rolePermissions) ? true : false, array('class' => 'name'))); ?>

                        Delete</label>
                </div>
            </div>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			<hr>
			<h5>Extra Permissions</h5>
			<hr>
			<div class="form-group row">
			
				 <?php $__currentLoopData = $extraPermission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3">
                        <label><?php echo e(Form::checkbox('permission[]', get_permission_id($value), in_array(get_permission_id($value), $rolePermissions) ? true : false, array('class' => 'name'))); ?>

						<?php echo e($key); ?></label>
                </div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
				
	
    <div class="card-footer clearfix">
        <div class="row">
            <div class="col">
                <a class="btn btn-danger btn-sm" href="<?php echo url('/admin/roles');; ?>">Cancel</a>
            </div>
            <div class="col text-right">
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>

        <?php echo Form::close(); ?>

        </div>
      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('admin.includes.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>