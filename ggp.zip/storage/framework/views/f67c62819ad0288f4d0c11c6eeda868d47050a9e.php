<body>
	<div id="site-content">
		<header class="site-header">
			<div class="top-header">
				<div class="container">
					<?php if(Session::get('language') == 'en'): ?>
					<?php
							$langg = Session::get('language');
						?>
					<?php else: ?>
						<?php
							$langg = '';
						?>
					<?php endif; ?>
					<a href="<?php echo e(url('/'.$langg)); ?>" id="branding">
						<img src="<?php echo e(url('frontend/images/gg-logo.png ')); ?>" alt="Company Name" class="logo logo-design">
						
					</a> <!-- #branding -->
				
					<div class="right-section pull-right">
						<a href="#" class="phone"><img src="<?php echo e(url('frontend/images/icon-phone.png')); ?>" class="icon">08-559 250 70</a>
				
						<form action="#" class="search-form">
							<?php echo csrf_field(); ?>
							<input type="text" placeholder="Search...">
							<button type="submit"><img src="<?php echo e(url('frontend/images/icon-search.png')); ?>" alt=""></button>

						</form>
					</div>
				</div> <!-- .container -->
			</div> <!-- .top-header -->

<?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>