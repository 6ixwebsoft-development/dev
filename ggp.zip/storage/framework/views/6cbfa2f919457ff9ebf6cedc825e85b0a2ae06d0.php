<?php $__env->startSection('content'); ?>
<main class="main-content">
				<div class="breadcrumbs">
					<div class="container">
						<a href="/"><?php echo e(__('word.'.strtolower('home'))); ?></a>
						<span><?php echo e(__('word.'.strtolower('foundation'))); ?> <?php echo e(__('word.'.strtolower('search'))); ?></span>
					</div>
				</div>

				<div class="page">
					<div class="container">

						<!-- <form action="" class="regform" method="get"> -->
						<?php echo Form::open(array('url' => 'simple-search-result', 'class' => 'regform', 'method' => 'GET')); ?>

						    <div class="row">
						    	<div class="col-md-12 text-center ">
						    		<h3 class="title"><?php echo e(__('word.'.strtolower('to find out which funds are right for you, we will now ask some questions'))); ?>  </h3>
						    		<strong><?php echo e(__('word.'.strtolower('select municipality you live'))); ?></strong>
						    	</div>
						    </div>
						    <div class="row">
						    	<div class="col-md-4">
						    	</div>
							    <div class="col-md-4">
							    	<div class="city_select">
							       
								        <div class="city_checkbox">
											<?php echo Form::select('city_ids[]',$city,[], ['class' => 'form-control','multiple','id'=>'cityDataFound']); ?>

								    	
								    	</div>
								   
							        </div>
							        <input class="submit_btn" type="submit" value="<?php echo e(__('word.'.strtolower('search'))); ?>" style="width: 100%;">
							    </div>
							    <div class="col-md-4">
							    </div>
						    </div>
						        
						    
						<?php echo Form::close(); ?>

					</div>

				</div> <!-- .page -->
			</main>
			<?php $__env->stopSection(); ?>
			
		
   
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/foundation-search.blade.php ENDPATH**/ ?>