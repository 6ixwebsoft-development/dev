<?php $__env->startSection('content'); ?>
<main class="main-content">
				<div class="breadcrumbs">
					<div class="container">
						<a href="/"><?php echo e(__('word.'.strtolower('home'))); ?></a>
						<span><?php echo e(__('word.'.strtolower('foundation'))); ?> <?php echo e(__('word.'.strtolower('search'))); ?></span>
					</div>
				</div>

				<div class="page">
					<div class="container">
						<div class="fund-details">
						</div>
					</div>
					<div class="container simple-fund-table">

						<div class="fund_email" style="position: relative;">
							<div class="mail-modal">
						        <div class="modal-overlay"></div>
						        <div class="modal-wrapper modal-transition">
						            <div class="modal-header">
						                <button class="modal-close mail-toggle">
						                    <i class="fa fa-times"></i>
						                </button>
						                <h2 class="modal-heading foundation-name"></h2>
						            </div>

						            <div class="modal-body">
						                <div class="modal-content">
						                	<?php echo Form::open(array('url' => 'fund-search-mail-send')); ?>


						                		<?php echo Form::text('email', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => __( 'Email' ) ]);; ?>

						                		<button type="submit" class="btn btn-primary">Send Email</button>
						                		<div class="mail-body"></div>
						                	<?php echo Form::close(); ?>


						                </div>
						            </div>
						        </div>
						    </div >
						</div>
						<?php echo Form::open(array('url' => 'simple-search-result', 'method' => 'GET')); ?>

						<table border="1"  class="table table-bordered" style="width:100%" id="f_table">
							<thead>
								<tr>
									<th><?php echo e(__('word.'.strtolower('row'))); ?></th>
									<th><input type="checkbox" name=""></th>
									<?php if(!Auth::guest()): ?>
									<th></th>
									<?php endif; ?>
									<th><?php echo e(__('word.'.strtolower('id'))); ?></th>
									<th><?php echo e(__('word.'.strtolower('name'))); ?></th>
									<th><?php echo e(__('word.'.strtolower('sort'))); ?></th>
									<th><?php echo e(__('word.'.strtolower('view'))); ?></th>
								</tr>
							</thead>
							<tbody id="fundsTable">
								<?php if(count($all_foundations) > 0): ?>
									<?php
										$i=0
									?>      
									<?php $__currentLoopData = $all_foundations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foundation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr class="fund-row <?php echo e(($i==0)?' selected':''); ?>"  data-id="<?php echo e($foundation->id); ?>">
										<td></td>
										<td><input type="checkbox" name="foundatoin_check" id="checked_foundation" value="<?php echo e($foundation->id); ?>" class="<?php echo e(($i==0)?'grey':''); ?>"></td>
										<?php if(!Auth::guest()): ?>
										<td>
										<?php if(in_array($foundation->id, $save_count) ): ?>
											<a href="#" id="saveSearchFoundation" class="heart-pink" data-id="<?php echo e($foundation->id); ?>"><i class="fa fa-heart"></i></a>
											<input type="hidden" name="favourite_fund_ids[]" value="<?php echo e($foundation->id); ?>">
										<?php else: ?>
											<a href="#" id="saveSearchFoundation" data-id="<?php echo e($foundation->id); ?>"><i class="fa fa-heart-o"></i></a>
										<?php endif; ?>
										</td>
										<?php endif; ?>
										<td><a href="foundation-detail/<?php echo e($foundation->id); ?>" class="f_id" id="foundation_id" data-id="<?php echo e($foundation->id); ?>"><?php echo e($foundation->id); ?></a></td>
										<td class="f-purpose">
											<a href="foundation-detail/<?php echo e($foundation->id); ?>" class="f_id" data-id="<?php echo e($foundation->id); ?>"><?php echo e($foundation->name); ?></a>
											<p><?php echo e(strlen($foundation->purpose) > 200 ? html_entity_decode(substr(strip_tags($foundation->purpose),0,200))."..." : html_entity_decode(strip_tags($foundation->purpose))); ?></p>
										</td>
										<td><?php echo e($foundation->sort); ?></td>
										<td><a href="foundation-detail/<?php echo e($foundation->id); ?>" class="f_id" data-id="<?php echo e($foundation->id); ?>"><i class="fa fa-search"></i></a>
										</td>
									</tr>
									<?php
										$i++;
									?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php
										$fundation_id = $foundation->id;
									?>
								<?php else: ?>
									<tr>
										<td colspan="6" class="text-center">No record found</td>
									</tr>
								<?php endif; ?>
								
							</tbody>
						</table>
						<div class="f-extra-info">
							<div class="row">
								<div class="col-md-12">
									<section class="popup-container">
									    <div class="popup-box">
									        <h3>About Subscriptions</h3>
									        <p>Lorem ipsum dolor amet consectetur adipiscing elit do eiusmod tempor incididunt labore dolore magna aliqua.</p>
									        <p>Lorem ipsum dolor amet consectetur adipiscing elit do eiusmod tempor incididunt labore dolore magna aliqua.</p>
									        <p>Lorem ipsum dolor amet consectetur adipiscing elit do eiusmod tempor incididunt labore dolore magna aliqua.</p>
									     </div>
									</section>
								</div>
								<div class="col-md-10">
									<div class="bulk-action">
										<ul>
											<li><?php echo e(__('word.'.strtolower('bulk actions'))); ?>: <a href="#" id="search_email"><?php echo e(__('word.'.strtolower('e-mail selected'))); ?></a></li>
											<li>|</li>
											<?php if(!Auth::guest()): ?>
											<li>
												<button type="submit" id="selected-favorite"></button><!-- <a href="#" id="selected-favorite"></a> -->
											</li>
											<?php endif; ?>
											<!-- /newcode/public/ -->
											<li><a href="/search-foundation" class="s-again"><?php echo e(__('word.'.strtolower('search again'))); ?></a></li>
											<!-- <li><a href="#" id="saveSearchFoundation">Save Foundations</a></li> -->
											
										</ul>
									</div>
									<?php if(Auth::guest()): ?>
									<div class="f-total-info text-center">
										<?php if($fund_count > 0): ?>
										<h3><?php echo e(__('word.'.strtolower('the list contains'))); ?> <?php echo e($fund_count); ?> <?php echo e(__('word.'.strtolower('more funds. do you want to see more funds'))); ?>?</h3>
										<?php endif; ?>
									</div>
									<div class="row">
									<?php if(empty(Session::get('remote_name'))): ?>
										<div class="col-md-6 subs-btn text-center">
											<a href="<?php echo e(url('en/remote')); ?>" class="acc-btn" >
											<?php echo e(__('word.'.strtolower('login with your library card'))); ?>

											</a>
										</div>
										
										<div class="col-md-6 subs-btn text-center">
											<a href="#" class="acc-btn" ><?php echo e(__('word.'.strtolower('buy a subscription for only'))); ?></a>
										</div>
										<?php endif; ?>
									</div>
									
									<?php else: ?>
										<?php if($fund_count > 10): ?>
										<!-- <div class="row">
											<div class="col-md-3"></div>
											<div class="col-md-6 text-center">
												<div class="moreFund">
													<button id="btn-more" data-id="<?php echo e($fundation_id); ?>" class="acc-btn btn-block" > Load More Funds </button>
												</div>
											</div>
											<div class="col-md-3"></div>
										</div> -->
										<?php endif; ?>
										<div class="f-total-info text-center">
											<h3><?php echo e(__('word.'.strtolower('the list contains'))); ?> <?php echo e($fund_count); ?> <?php echo e(__('word.'.strtolower('more funds. do you want to see more funds'))); ?>?</h3>
										</div>
										<div class="row">
											<div class="col-md-6 subs-btn text-center">
												<a href="/remote" class="acc-btn" ><?php echo e(__('word.'.strtolower('login with your library card'))); ?></a>
											</div>
											<div class="col-md-6 subs-btn text-center">
												<a href="#" class="acc-btn" ><?php echo e(__('word.'.strtolower('buy a subscription for only'))); ?></a>
											</div>
										</div>
									<?php endif; ?>

								</div>
								<?php echo Form::close(); ?>


								<div class="col-md-2">
									<div class="row">
										<div class="col-md-12">
											<img class="help_subscription" src="frontend/images/help.png" alt="help">
										</div>
									</div>
								</div>
							</div>
						</div>


					</div>
				</div> <!-- .page -->
			</main>
			<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/simple-search-result.blade.php ENDPATH**/ ?>