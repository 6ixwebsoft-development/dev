<?php if(empty($ajax)): ?>

<?php $__env->startSection('content'); ?>
<?php endif; ?>
<main class="main-content">

	<div class="page">
		<div class="container">
			<div  class="fund-detail" id="loaderarea" style="display:none">
				<img src="<?php echo e(url('frontend/images/loader.gif ')); ?>" />
			</div>
			<div class="fund-detail">
				<?php $__currentLoopData = $foundation_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foundation_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div>
						<?php if(!empty($previd)): ?>
						<a class="btn btn-info" onClick="getFoundationDetailajax(<?php echo e($previd); ?>,-1);">Previous</a> 
						<?php endif; ?>
						<?php if(!empty($nextid)): ?>
						<a class="btn btn-info" onClick="getFoundationDetailajax(<?php echo e($nextid); ?>,1);">next</a>
						<?php endif; ?>
					<br>
					</div>
					<div class="fundTitle">
						<strong>ID <?php echo e($foundation_detail->id); ?> - <?php echo e($foundation_detail->name); ?></strong>
					</div>
					<div class="fundPurpose">
						<p>
						<?php echo e($foundation_detail->purpose); ?>

						</p>
					</div>
					<div class="fundWhoCanApply">
						<p><?php echo e(strip_tags($foundation_detail->who_can_apply)); ?></p>
					</div>
					<!-- <div class="fundRemarks">
						<p><?php echo e(strip_tags($foundation_detail->remarks)); ?></p>
					</div> -->
					<div class="fundDetails">
						<p><?php echo e(strip_tags($foundation_detail->details)); ?></p>
					</div>
					<div class="fundContacts">
						<p> 
						ADRESS :<?php echo e($foundation_detail->address1); ?> <?php echo e($foundation_detail->address2); ?>, <?php echo e($foundation_detail->address3); ?>,Tel : <?php echo e($foundation_detail->phone_no); ?><br>
						<?php echo e($foundation_detail->email); ?>,<a href="<?php echo e($foundation_detail->website); ?>"><?php echo e($foundation_detail->website); ?></a>
						</p>
						<!-- <h4>Contacts</h4>
						<p><?php echo e($foundation_detail->address1); ?></p>
						<p><?php echo e($foundation_detail->address2); ?></p>
						<p><?php echo e($foundation_detail->address3); ?></p>
						<br>
						<p>Telephone: <?php echo e($foundation_detail->phone_no); ?></p>
						<p>Email: <?php echo e($foundation_detail->email); ?></p>
						<p>Website: <a href="<?php echo e($foundation_detail->website); ?>"><?php echo e($foundation_detail->website); ?></a></p> -->
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<a href="#" onclick="window.history.go(-1); return false;" class="back-to-hitist">BACK TO HITLIST</a>
			</div>
		</div>
	</div> <!-- .page -->
</main>
<?php if(empty($ajax)): ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/foundation-detail.blade.php ENDPATH**/ ?>