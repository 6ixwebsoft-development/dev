<div class="model__button_top">
		<?php if(!empty($previd)): ?>
		<a class="btn btn-info" onClick="getFoundationDetailajax(<?php echo e($previd); ?>,-1);"><< Previous</a> 
		<?php endif; ?>
		<?php if(!empty($nextid)): ?>
		<a class="btn btn-info" onClick="getFoundationDetailajax(<?php echo e($nextid); ?>,1);">Next >></a>
		<?php endif; ?>
	<br>
	</div>
<main class="main-content">
				
	<div class="page">
		<div class="container">
			
				
			<div class="fund-detail">
				<?php $__currentLoopData = $foundation_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foundation_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<div style="">
					<div class="fundTitle">
						<strong><?php echo e($foundation_detail->id); ?> - <?php echo e($foundation_detail->name); ?></strong>
					</div>
					<div class="fundPurpose">
						<p>
						PURPOSE : <?php echo e(strip_tags($foundation_detail->purpose)); ?></p>
					</div>
					<div class="fundWhoCanApply">
						<p>
					
					WHO CAN SEARCH : 	<?php echo e(strip_tags($foundation_detail->who_can_apply)); ?></p>
					</div>
					<div class="fundRemarks">
						<p>
						APPLICATION :
						<?php echo e(strip_tags($foundation_detail->remarks)); ?></p>
					</div>
					<div class="fundDetails">
						<p> 
						<?php echo e(strip_tags($foundation_detail->details)); ?></p>
					</div>
					<div class="fundContacts">
						<p> 
						ADRESS :<?php echo e($foundation_detail->address1); ?> <?php echo e($foundation_detail->address2); ?>, <?php echo e($foundation_detail->address3); ?>,Tel : <?php echo e($foundation_detail->phone_no); ?><br>
						<?php echo e($foundation_detail->email); ?>,<a href="<?php echo e($foundation_detail->website); ?>"><?php echo e($foundation_detail->website); ?></a>
						</p>
					
						<!--<h4>Contacts</h4>
						<p><?php echo e($foundation_detail->address1); ?></p> -->
						<!--<p><?php echo e($foundation_detail->address2); ?></p>
						<p><?php echo e($foundation_detail->address3); ?></p>
						<br>
						<p>Telephone: <?php echo e($foundation_detail->phone_no); ?></p>
						<p>Email: <?php echo e($foundation_detail->email); ?></p>
						<p>Website: <a href="<?php echo e($foundation_detail->website); ?>"><?php echo e($foundation_detail->website); ?></a></p> -->
					</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
				
			</div>
		</div>
	</div> <!-- .page -->
	<div class="model__button_bottom">
		<a href="#" onclick="window.history.go(-1); return false;" class="btn btn-info back-to-hitist">BACK TO HITLIST</a>
	</div>
</main>

<?php /**PATH C:\xampp\htdocs\git\ggp\resources\views/foundation-detailajax.blade.php ENDPATH**/ ?>