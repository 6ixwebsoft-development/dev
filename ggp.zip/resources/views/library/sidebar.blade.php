<div class="col-sm-3 col-md-6 col-lg-3" >
		<ul class="list-group">
			<li class="list-group-item"><a href="{{ url('/library/manage/information') }}">YOUR NAME</a></li>
			<li class="list-group-item"><a href="{{ url('/library/manage/login') }}"> -YOUR LOGIN DETAILS</a></li>
			<li class="list-group-item"><a href="{{ url('/library/manage/contact') }}"> -YOUR CONTACT DETAILS</a></li>
			<li class="list-group-item"><a href="{{ url('/library/manage/ip-setting') }}"> -IP LOGIN</a></li>
			<li class="list-group-item"><a href="{{ url('/library/manage/remote-access') }}"> -REMOTE ACCESS</a></li>
			<li class="list-group-item"><a href="{{ url('/library/manage/remote-arena') }}"> -DOMAIN NAME PIN</a></li>
			<li class="list-group-item"><a href="{{ url('/library/manage/static-report') }}">REPORTS</a></li>
			<li class="list-group-item"><a href="{{ url('/library/manage/account-history') }}">ORDER HISTORY</a></li>
			
		  </ul>
    </div>