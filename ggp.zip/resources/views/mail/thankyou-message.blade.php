@extends('layouts.mainlayout')
@section('content')
<main class="main-content">

	<div class="page">
		<div class="container">
			<h1>{{ __('word.email has been sent successfully')}}</h1>
		</div>
	</div> <!-- .page -->
</main>
@endsection