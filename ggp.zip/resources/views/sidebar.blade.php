<div id="admin-sidebar" class="col-md-3 p-x-0 p-y-3">
                <ul class="sidenav admin-sidenav list-unstyled">
                    <li><a href="#">- YOUR SAVED FUND RECORDS</a></li>
                    <li><a href="#">- YOUR NAME</a></li>
                    <li><a href="#">- YOUR CONTACT DETAILS</a></li>
                    <li><a href="#">- YOUR LOGIN DETAILS</a></li>
                    <li><a href="#">- REGISTER YOUR LIBRARY CARD</a></li>                 
                </ul>
            </div>