<div class="col-sm-3 col-md-6 col-lg-3" >
		<ul class="list-group">
			<li class="list-group-item"><a href="{{ url('/customer/edit/foundations') }}">YOUR SAVED FUND RECORDS</a></li>
			<li class="list-group-item"><a href="{{ url('/customer/edit/basicinfo') }}">YOUR NAME</a></li>
			<li class="list-group-item"><a href="{{ url('/customer/edit/contactinfo') }}">YOUR CONTACT DETAILS</a></li>
			<li class="list-group-item"><a href="{{ url('/customer/edit/admin') }}"> YOUR LOGIN DETAILS</a></li>
			<li class="list-group-item"><a href="{{ url('/customer/edit/cardnumber') }}"> - REGISTER YOUR LIBRARY CARD</a></li>
			
		  </ul>
    </div>
