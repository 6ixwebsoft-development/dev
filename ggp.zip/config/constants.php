<?php

return [
    'settings' => [
        'LANGUAGE_ID' => 1,
        'USER_ROLE'   => 4,
    ]
];